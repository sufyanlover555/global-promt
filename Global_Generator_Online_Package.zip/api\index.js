const server = require('../server.js');

module.exports = (req, res) => {
    // If Vercel changed req.url to /api/index.js, restore the original path
    const realPath = (req.query && req.query.__endpoint)
                  || req.headers['x-matched-path'] 
                  || req.headers['x-forwarded-uri'] 
                  || req.headers['x-invoke-path'];
    if (realPath && (req.url === '/api/index.js' || req.url === '/api' || req.url.startsWith('/api/index.js?'))) {
        req.url = realPath;
    }
    return server.emit('request', req, res);
};
